import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

import { COLORS } from '../../constants/colors';
import { authService } from '../../services/authService';
import useAppStore from '../../store/appStore';
import PhoneInput from '../../components/PhoneInput';
import { toE164 } from '../../utils/validation';

const LoginScreen = ({ navigation, route }) => {
  const isPartnerLogin = route?.name === 'PartnerLogin';
  const partnerRole = route?.params?.role;
  const storeCountry = useAppStore((state) => state.country);

  const [phone, setPhone] = useState('');
  const [phoneE164, setPhoneE164] = useState('');
  const [phoneValid, setPhoneValid] = useState(false);
  const [country, setCountry] = useState(storeCountry);
  const [password, setPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [passwordFocused, setPasswordFocused] = useState(false);
  const loginScale = React.useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const prefilledPhone = route?.params?.phone;
    const prefilledPassword = route?.params?.password;
    const prefilledCountry = route?.params?.countryCode || storeCountry;

    if (!prefilledPhone) {
      return;
    }

    const nationalPhone = String(prefilledPhone).replace(/\D/g, '');

    setPhone(nationalPhone);
    setPhoneE164(toE164(nationalPhone, prefilledCountry));
    setPhoneValid(Boolean(nationalPhone));
    setCountry(prefilledCountry);

    if (prefilledPassword) {
      setPassword(prefilledPassword);
    }
  }, [route?.params?.phone, route?.params?.countryCode, route?.params?.password, storeCountry]);

  const handlePhoneChange = ({ national, e164, isValid, countryCode }) => {
    setPhone(national);
    setPhoneE164(e164);
    setPhoneValid(isValid);
    setCountry(countryCode);
  };

  // ==========================================
  // LOGIN
  // ==========================================

  const handleLogin = async () => {
    if (!phone) {
      Alert.alert('تنبيه', 'من فضلك أدخل رقم الهاتف');
      return;
    }

    if (!password) {
      Alert.alert('تنبيه', 'من فضلك أدخل كلمة المرور');
      return;
    }

    if (!phoneValid) {
      Alert.alert('تنبيه', 'رقم الهاتف غير صحيح لهذه الدولة');
      return;
    }

    try {
      setLoading(true);

      // Send the canonical E.164 value first; retry the legacy local format
      // only for older deployments that still store Egyptian numbers locally.
      const loginPhone = phoneE164 || phone;
      let result = await authService.login(loginPhone, password);
      const legacyPhone =
        country === 'EG' && !phone.startsWith('0') ? `0${phone}` : phone;
      if (!result?.success && legacyPhone !== loginPhone) {
        result = await authService.login(legacyPhone, password);
      }

      if (!result?.success) {
        Alert.alert(
          'تعذر تسجيل الدخول',
          result?.message || 'بيانات الدخول غير صحيحة'
        );

        return;
      }

      /*
        لا نعمل navigation يدوي هنا.

        RootNavigator هو المسؤول عن قراءة
        حالة المستخدم وتحديد الشاشة المناسبة:

        CUSTOMER
        VENDOR
        DELIVERY
      */

    } catch (error) {
      console.error('LOGIN SCREEN ERROR:', error);

      Alert.alert(
        'خطأ',
        'حدث خطأ أثناء تسجيل الدخول. حاول مرة أخرى'
      );
    } finally {
      setLoading(false);
    }
  };

  const animateLoginButton = (toValue) => {
    Animated.spring(loginScale, {
      toValue,
      useNativeDriver: true,
      friction: 7,
      tension: 120,
    }).start();
  };

  // ==========================================
  // GUEST
  // ==========================================

  const handleGuestMode = () => {
    navigation.replace('GuestHome');
  };

  // ==========================================
  // REGISTER
  // ==========================================

  const handleRegister = () => {
    navigation.navigate(
      isPartnerLogin ? 'PartnerRegistration' : 'Register',
      isPartnerLogin && partnerRole ? { role: partnerRole } : undefined
    );
  };

  // ==========================================
  // ABOUT
  // ==========================================

  const handleAbout = () => {
    navigation.navigate('About');
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={
        Platform.OS === 'ios'
          ? 'padding'
          : undefined
      }
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scrollContent}
      >
        {/* ======================================
            HEADER
        ====================================== */}

        <LinearGradient
          colors={[
            COLORS.primary,
            COLORS.secondary,
          ]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.header}
        >
          <View style={styles.logoCircle}>
            <Ionicons
              name="flash"
              size={42}
              color="#FFFFFF"
            />
          </View>

          <Text style={styles.title}>
            NOW
          </Text>

          <Text style={styles.subtitle}>
            كل طلباتك... في مكان واحد
          </Text>
        </LinearGradient>

        {/* ======================================
            FORM
        ====================================== */}

        <View style={styles.formCard}>
          <Text style={styles.welcomeTitle}>
            {isPartnerLogin ? 'تسجيل دخول الشريك' : 'أهلاً بيك 👋'}
          </Text>

          <Text style={styles.welcomeSubtitle}>
            {isPartnerLogin
              ? 'ادخل لإدارة متجرك أو متابعة طلبات التوصيل'
              : 'سجل دخولك علشان تكمل استخدام NOW'}
          </Text>

          {/* ====================================
              PHONE
          ==================================== */}

          <Text style={styles.label}>
            رقم الهاتف
          </Text>

          <PhoneInput
            value={phone}
            countryCode={country}
            onChange={handlePhoneChange}
          />
          {phone.length > 0 && !phoneValid && (
            <Text style={styles.validationText}>
              أدخل رقم هاتف صحيح للمتابعة
            </Text>
          )}

          {/* ====================================
              PASSWORD
          ==================================== */}

          <Text style={styles.label}>
            كلمة المرور
          </Text>

          <View
            style={[
              styles.inputContainer,
              passwordFocused &&
                styles.inputContainerFocused,
            ]}
          >
            <Ionicons
              name="lock-closed-outline"
              size={21}
              color={
                passwordFocused
                  ? COLORS.primary
                  : COLORS.textSecondary
              }
              style={styles.inputIcon}
            />

            <TextInput
              style={styles.input}
              placeholder="أدخل كلمة المرور"
              placeholderTextColor={COLORS.textLight}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              autoComplete="password"
              textContentType="password"
              onFocus={() =>
                setPasswordFocused(true)
              }
              onBlur={() =>
                setPasswordFocused(false)
              }
              onSubmitEditing={handleLogin}
              returnKeyType="done"
            />

            <TouchableOpacity
              onPress={() =>
                setShowPassword(
                  (previous) => !previous
                )
              }
              style={styles.eyeButton}
              activeOpacity={0.7}
            >
              <Ionicons
                name={
                  showPassword
                    ? 'eye-outline'
                    : 'eye-off-outline'
                }
                size={21}
                color={COLORS.textSecondary}
              />
            </TouchableOpacity>
          </View>

          {/* ====================================
              LOGIN BUTTON
          ==================================== */}

          <TouchableOpacity
            onPress={handleLogin}
            disabled={loading}
            accessibilityLabel="تسجيل الدخول"
            activeOpacity={0.85}
            onPressIn={() => animateLoginButton(0.96)}
            onPressOut={() => animateLoginButton(1)}
            style={[
              styles.loginButton,
              loading && styles.loginButtonDisabled,
              { transform: [{ scale: loginScale }] },
            ]}
          >
            <LinearGradient
              colors={[COLORS.primary, COLORS.primaryDark]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.loginGradient}
            >
              {loading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="small" color="#FFFFFF" />
                </View>
              ) : (
                <View style={styles.buttonContent}>
                  <Text style={styles.loginButtonText}>دخول</Text>
                  <Ionicons name="arrow-forward" size={21} color="#FFFFFF" />
                </View>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* ====================================
              REGISTER
          ==================================== */}

          <View style={styles.registerContainer}>
            <Text style={styles.registerText}>
              {isPartnerLogin ? 'لسه معندكش حساب شريك؟' : 'لسه معندكش حساب؟'}
            </Text>

            <TouchableOpacity
              onPress={handleRegister}
              disabled={loading}
              activeOpacity={0.7}
            >
              <Text style={styles.registerLink}>
                  {isPartnerLogin ? 'تسجيل شريك جديد' : 'إنشاء حساب'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* ====================================
              GUEST
          ==================================== */}

          <TouchableOpacity
            onPress={handleGuestMode}
            disabled={loading}
            style={styles.guestButton}
            activeOpacity={0.7}
          >
            <Ionicons
              name="bag-handle-outline"
              size={20}
              color={COLORS.primary}
            />

            <Text style={styles.guestText}>
              تصفح كزائر
            </Text>
          </TouchableOpacity>

          {/* ====================================
              ABOUT
          ==================================== */}

          <TouchableOpacity
            onPress={handleAbout}
            disabled={loading}
            style={styles.aboutButton}
            activeOpacity={0.7}
          >
            <Ionicons
              name="information-circle-outline"
              size={18}
              color={COLORS.textSecondary}
            />

            <Text style={styles.aboutText}>
              حول تطبيق NOW
            </Text>
          </TouchableOpacity>
        </View>

        {/* ======================================
            FOOTER
        ====================================== */}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            NOW © 2026
          </Text>

          <Text style={styles.footerSubText}>
            طلبك يوصل... في وقته
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

// ==========================================
// STYLES
// ==========================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  scrollContent: {
    flexGrow: 1,
    paddingBottom: 25,
  },

  // ========================================
  // HEADER
  // ========================================

  header: {
    height: 250,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 20,
    borderBottomLeftRadius: 42,
    borderBottomRightRadius: 42,
  },

  logoCircle: {
    width: 78,
    height: 78,
    borderRadius: 39,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },

  title: {
    color: '#FFFFFF',
    fontSize: 42,
    fontWeight: '800',
    letterSpacing: 1,
  },

  subtitle: {
    color: '#FFFFFF',
    fontSize: 15,
    opacity: 0.9,
    marginTop: 5,
  },

  // ========================================
  // FORM
  // ========================================

  formCard: {
    backgroundColor: COLORS.background,
    marginHorizontal: 16,
    marginTop: -25,
    borderRadius: 28,
    padding: 22,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.08,
    shadowRadius: 15,

    elevation: 5,
  },

  welcomeTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: COLORS.textPrimary,
    textAlign: 'right',
    marginBottom: 5,
  },

  welcomeSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'right',
    marginBottom: 25,
  },

  label: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.textPrimary,
    textAlign: 'right',
    marginBottom: 8,
  },

  // ========================================
  // INPUT
  // ========================================

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    paddingHorizontal: 12,
    marginBottom: 17,
    minHeight: 55,
  },

  inputContainerFocused: {
    borderColor: COLORS.primary,
    backgroundColor: '#FFF9FC',
  },

  inputIcon: {
    marginRight: 9,
  },

  input: {
    flex: 1,
    color: COLORS.textPrimary,
    fontSize: 16,
    paddingVertical: 13,
    textAlign: 'right',
  },

  validationText: {
    marginTop: -10,
    marginBottom: 10,
    color: COLORS.error,
    fontSize: 12,
    textAlign: 'right',
  },

  eyeButton: {
    padding: 7,
    marginLeft: 5,
  },

  // ========================================
  // LOGIN BUTTON
  // ========================================

  loginButton: {
    marginTop: 5,
    borderRadius: 28,
    overflow: 'hidden',
    alignSelf: 'center',
    width: 150,
    height: 58,
    shadowColor: '#06B6D4',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.28,
    shadowRadius: 12,
    elevation: 7,
  },

  loginButtonDisabled: {
    opacity: 0.75,
  },

  loginGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },

  loginButtonText: {
    color: COLORS.white,
    fontSize: 17,
    fontWeight: '800',
  },

  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },

  // ========================================
  // REGISTER
  // ========================================

  registerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 23,
    gap: 5,
  },

  registerText: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },

  registerLink: {
    color: COLORS.primary,
    fontSize: 15,
    fontWeight: '800',
  },

  supportLink: {
    alignSelf: 'center',
    marginTop: 8,
  },

  supportText: {
    color: COLORS.primary,
    fontSize: 13,
    fontWeight: '700',
  },

  // ========================================
  // GUEST
  // ========================================

  guestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    marginTop: 20,
    paddingVertical: 13,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: COLORS.primary,
    backgroundColor: '#FFF8FB',
  },

  guestText: {
    color: COLORS.primary,
    fontSize: 15,
    fontWeight: '700',
  },

  // ========================================
  // ABOUT
  // ========================================

  aboutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 14,
  },

  aboutText: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },

  // ========================================
  // FOOTER
  // ========================================

  footer: {
    alignItems: 'center',
    marginTop: 20,
  },

  footerText: {
    color: COLORS.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },

  footerSubText: {
    color: COLORS.textLight,
    fontSize: 12,
    marginTop: 4,
  },
});

export default LoginScreen;
// مسودة المشروع - البشمهندس حسن ياسر