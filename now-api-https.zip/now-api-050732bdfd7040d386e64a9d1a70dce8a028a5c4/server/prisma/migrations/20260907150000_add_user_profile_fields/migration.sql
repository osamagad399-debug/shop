ALTER TABLE "users"
ADD COLUMN "profileImage" TEXT,
ADD COLUMN "latitude" DECIMAL(9,6),
ADD COLUMN "longitude" DECIMAL(9,6);
